from lib.interface import *

def arquivoexiste(nome):
    try:
        arq=open(nome,'rt')
        arq.close()
    except FileNotFoundError:
        print( 'ERRO,PARECE QUE O ARQUIVO QUE ESTÁ TENTANDO ABRIR NÃO EXISTE NO SEU DIRETÓRIO.')
        return False
    else:
        return True

def criarArquivo(nome):
    try:
        arquivo=open(nome,'w+')
        arquivo.close()
    except:
        print('HOUVE UM ERRO NA CRIAÇÃO DO ARQUIVO.')
    else:
        print(f'Arquivo {nome} criado com sucesso.')

def lerArquivo(nome):
    try:
        a=open(nome,'rt')
    except:
        print('Erro,não conseguiu abrir o arquivo.')
    else:
        cabeçalho('PESSOAS CADASTRADAS')
        for linha in a:
            dado=linha.split(';')
            dado[1]=dado[1].replace('\n','')
            print(f'{dado[0]:<30}{dado[1]:>3} anos')
    finally:
        a.close()
def Cadastrar(arq,nome='Desconhecido',idade=0):
    try:
        a=open(arq,'at')
    except:
        print('HOUVE UM ERRO DE ABERTURA DO SEU ARQUIVO.')
    else:
        try:
            a.write(f'{nome};{idade}\n')
        except:
            print('HOUVE UM ERRO DE DIGITAÇÃO DOS DADOS.')
        else:
            print(f'Dados do usuário {nome} cadastrados com sucesso!')
            a.close()