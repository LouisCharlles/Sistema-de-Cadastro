from lib.interface import *
from lib.Arquivo.Arquivos import *
from time import sleep

arq='Pessoas_Cadastradas.txt'
if not arquivoexiste(arq):
    criarArquivo(arq)

while True:
    resposta=menu(['Ver pessoas cadastradas','Cadastrar nova Pessoa','Sair do Sistema'])
    if resposta==1:
        cabeçalho('PESSOAS CADASTRADAS')
        lerArquivo(arq)
    elif resposta==2:
        cabeçalho('NOVO CADASTRO')
        nome=str(input('Digite o nome:'))
        idade=leiainteiro('Digite a idade:')
        Cadastrar(arq,nome,idade)
    elif resposta==3:
        cabeçalho('Até logo:)')
        break
    sleep(1)
