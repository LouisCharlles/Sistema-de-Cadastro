def leiainteiro(msg):
    while True:
        try:
            n=int(input(msg))
        except ValueError:
            print('ERRO DE VALOR,POR FAVOR INSIRA UM VALOR INTEIRO.')
            continue
        except KeyboardInterrupt:
            print('ERRO! O USUÁRIO NÃO TERMINOU DE DIGITAR O VALOR.')
            return 0
        else:
            return n

def linha():
    print('-'* 42)

def cabeçalho(msg):
    linha()
    print(msg.center(42))
    linha()

def menu(lista):
    cabeçalho('MENU DE OPÇÕES')
    c=0
    while c!=len(lista):
        print(f'{c+1}-{lista[c]}')
        c+=1
    linha()
    opção=leiainteiro('EScolha a opção que desejar:')
    return opção